﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfTheAionProject.Models;

namespace WpfTheAionProject.DataLayer
{
    /// <summary>
    /// static class to store the game data set
    /// </summary>
    public static class GameData
    {
        public static Player PlayerData()
        {
            return new Player()
            {
                Id = 1,
                Name = "Dostya",
                Age = 43,
                FactionAcceptence = "Normal",
                Race = Character.RaceType.Cybran,
                Health = 100,
                Lives = 3,
                LocationId = 0,
                ThreatLevel = 5,
                SeraThreat = 2
            };
        }

        public static List<string> InitialMessages()
        {
            return new List<string>()
            {
                "You are the diplomate for your faction that has been sent out to try to make peace with the other factions in order to fight the seraphim."
            };
        }
    }
}
